﻿namespace Algorithm
{
    public class QueryData
    {
        public string definition;
        public int compareCount;
    }
}