﻿using System;

public class Word
{
    public String key, definition;

    public Word(string k, string d)
    {
        key = k;
        definition = d;
    }
}
